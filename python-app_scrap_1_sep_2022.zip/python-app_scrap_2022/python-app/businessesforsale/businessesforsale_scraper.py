import json
import os
from time import sleep

import pymysql
import requests


def get_listings_from_source(page_source, page_state):
    current_result_list = []
    for x in page_source.split('<div class="textInfo">')[1:]:
        if 'data-listing-id="' not in x:
            continue
        image = ''
        if 'data-defer-url=\'' in x:
            image = x.split('data-defer-url=\'')[1].split('\'')[0]
        elif 'background-image: url(' in x:
            image = x.split('background-image: url(')[1].split(')')[0]
        current_result_list.append({
            'url': x.split('<b class="title">')[1].split('href="')[1].split('?')[0],
            'address':
                x.split('<span class="price">')[1].split('</span')[0].split('Find Other ')[1].split(' Businesses')[
                    0] if 'Find Other' in x.split('<span class="price">')[1].split('</span')[0] else page_state,
            'price': x.split('<span class="asking"><b>')[1].split('</b')[0].replace('$', '').replace(',', ''),
            'image': image,
            'description': x.split('<p class="desc short">')[1].split('<a')[0] if '<p class="desc short">' in x else
            x.split('<p class="desc">')[1].split('<a')[0],
            'id': x.split('data-listing-id="')[1].split('"')[0],
            'name': x.split('<b class="title">')[1].split('">')[1].split('</a')[0],
            'city': '',
            'state': page_state
        })
    return current_result_list


def do_work(combo):
    c_state = combo['state']
    c_page = combo['page']
    PROXY_RACK_DNS = "private.residential.proxyrack.net:10003"
    proxy = {"http": "http://{}:{}@{}".format('bpp', 'f4dd72-734c77-b17307-e52946-eeeccb', PROXY_RACK_DNS)}

    state_url = c_state['url'] + 'page-%s/' % str(c_page)
    state_name = c_state['state']
    print('Checking %s' % state_url)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 '
                      'Safari/537.36 '
    }
    # Grab fpage results
    print('Checking page..')
    page_resp = requests.get(state_url, headers=headers, proxies=proxy).text
    page_results = get_listings_from_source(page_resp, state_name)
    print('Got %s results' % len(page_results))
    return page_results


if __name__ == '__main__':
    # Header
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36'
    }

    thread_count = 10

    # Load proxy list, grab proxy for current run
    real_path = os.path.dirname(__file__)
    proxy_list = []
    with open(real_path + '/proxies.txt', 'r') as f:
        for line in f.readlines():
            if len(line.strip()) > 5:
                proxy_list.append(line.strip())

    # Create mysql connection
    connection = pymysql.connect(host="132.148.75.250", user="businesspartnership", password="Businesspartnership@123",
                                 db="bpp_staging",
                                 charset="utf8mb4", port=3306, cursorclass=pymysql.cursors.DictCursor)

    # Grab current state count
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM settings WHERE name=\"businessforsale_current_run\"")
        result = cursor.fetchone()
        current_state_run = int(result['value'])

    # Load state list
    state_list = json.load(open(real_path + '/state_list.json', 'rb'))
    current_state = state_list[current_state_run % len(state_list)]
    print('Loaded %s states | Current: %s' % (len(state_list), current_state))

    # Grab results
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.82 '
                      'Safari/537.36 '
    }
    results = []
    state_url = 'https://us.businessesforsale.com/us/search?keywords=%s&formName=searchFilterForm&Sort=BestMatch&PageSize=100000&RegionTier%%5B0%%5D=23501&RegionSuggest%%5B1%%5D=Type+a+country+here...&RegionTier%%5B1%%5D=&RegionSuggest%%5B2%%5D=Type+a+region+here...&RegionTier%%5B2%%5D=&RegionSuggest%%5B3%%5D=Type+a+state+here...&RegionTier%%5B3%%5D=&RegionSuggest%%5B4%%5D=Type+a+city+here...&CategoryTier%%5B0%%5D=1&CategoryTier%%5B1%%5D=&CategoryTier%%5B2%%5D=&Price.From=&Price.To=&Profit.From=&Price.To=&Turnover.From=&Turnover.To=&Age=' % current_state
    state_resp = requests.get(state_url, headers=headers).text
    for result_str in state_resp.split('<div class="result">')[1:]:
        try:
            results.append({
                'url': result_str.split('href="')[1].split('"')[0],
                'address': result_str.split('<td>')[1].split('</td')[0],
                'price': result_str.split('<td>')[4].split('</td')[0].replace('$', '').replace(',', '').strip() if (
                            'request' not in result_str.split('<td>')[4].split('</td')[0] and '-' not in
                            result_str.split('<td>')[4].split('</td')[0]) else 0,
                'image': result_str.split('data-src="')[1].split('"')[0],
                'description': result_str.split('<p>')[1].split('</p')[0].split('<a')[0].strip(),
                'id': result_str.split('addAdvertId=')[1].split('"')[0],
                'name': result_str.split('href="')[1].split('">')[1].split('</')[0],
                'city': '',
                'state': current_state
            })
        except:
            continue

    # Loop through old id list and only grab new results
    old_id_list = json.load(open(real_path + '/old_id_list.json', 'rb'))
    new_result_list = []
    for result in results:
        if result['id'] not in old_id_list:
            new_result_list.append(result)
            old_id_list.append(result['id'])
    print('Found %s new results' % len(new_result_list))

    # Write new ids in old id list
    json.dump(old_id_list, open(real_path + '/old_id_list.json', 'w'))

    # Attempt to insert into database
    print('Inserting..')
    with connection.cursor() as cursor:
        insert_sql = 'INSERT INTO business_listing (source, unique_id, title, business_type, business_url, business_image, business_address, city, state, '\
                     'business_price, description) VALUES ("businessesforsale", %s, %s, "6", %s, %s, %s, %s, %s, %s, ' \
                     '%s) ON DUPLICATE KEY UPDATE id=id '

        cursor.executemany(insert_sql, [
            [x['id'], x['name'], x['url'], x['image'], x['address'], x['city'], x['state'], x['price'],
             x['description']] for x in new_result_list
        ])

        connection.commit()
        print('Done inserting!')

    # Increment current run by 1
    print('Updating current run..')
    with connection.cursor() as cursor:
        update_sql = 'UPDATE settings SET value=value+1 WHERE name="businessforsale_current_run"'
        cursor.execute(update_sql)
        connection.commit()
        print('Done updating current run!')

    sleep(2)
