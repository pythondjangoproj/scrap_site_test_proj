import requests
import json
import os
import pymysql
import random
import multiprocessing
from time import sleep
import math
import pyperclip


def get_listings_from_source(page_source, page_state):
    current_result_list = []
    for x in page_source.split('<div class="textInfo">')[1:]:
        if 'data-listing-id="' not in x:
            continue
        image = ''
        if 'data-defer-url=\'' in x:
            image = x.split('data-defer-url=\'')[1].split('\'')[0]
        elif 'background-image: url(' in x:
            image = x.split('background-image: url(')[1].split(')')[0].replace("'","")
        current_result_list.append({
            'url': x.split('<b class="title">')[1].split('href="')[1].split('?')[0],
            'address':
                x.split('<span class="price">')[1].split('</span')[0].split('Find Other ')[1].split(' Businesses')[
                    0] if 'Find Other' in x.split('<span class="price">')[1].split('</span')[0] else page_state,
            'price': x.split('<span class="asking"><b>')[1].split('</b')[0].replace('$', '').replace(',', ''),
            'image': image,
            'description': x.split('<p class="desc short">')[1].split('<a')[0] if '<p class="desc short">' in x else
            x.split('<p class="desc">')[1].split('<a')[0],
            'id': x.split('data-listing-id="')[1].split('"')[0],
            'name': x.split('<b class="title">')[1].split('">')[1].split('</a')[0],
            'city': '',
            'state': page_state
        })
    return current_result_list


def do_work(combo):
    c_state = combo['state']
    c_page = combo['page']
    PROXY_RACK_DNS = "private.residential.proxyrack.net:10003"
    proxy = {"http": "http://{}:{}@{}".format('bpp', 'f4dd72-734c77-b17307-e52946-eeeccb', PROXY_RACK_DNS)}

    state_url = c_state['url'] + 'page-%s/' % str(c_page)
    state_name = c_state['state']
    print('Checking %s' % state_url)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 '
                      'Safari/537.36 '
    }

    # Grab fpage results
    print('Checking page..')
    page_resp = requests.get(state_url, headers=headers, proxies=proxy).text
    page_results = get_listings_from_source(page_resp, state_name)
    print('Got %s results' % len(page_results))
    return page_results


if __name__ == '__main__':
    # Header
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 '
                      'Safari/537.36 '
    }

    thread_count = 10

    # Load proxy list, grab proxy for current run
    real_path = os.path.dirname(__file__)
    proxy_list = []
    with open(real_path + '/proxies.txt', 'r') as f:
        for line in f.readlines():
            if len(line.strip()) > 5:
                proxy_list.append(line.strip())

    # Create mysql connection
    # connection = pymysql.connect(host="localhost", user="businesspartnership", password="Businesspartnership@123",
    #                              db="bpp_staging",
    #                              charset="utf8mb4", port=3306, cursorclass=pymysql.cursors.DictCursor)

    # connection = pymysql.connect(host="132.148.75.250", user="businesspartnership", password="Businesspartnership@123",
    #                              db="bpp_staging",
    #                              charset="utf8mb4", port=3306, cursorclass=pymysql.cursors.DictCursor)

    connection = pymysql.connect(host="localhost", user="chetu", password="@evDjJ5_Cb)gD0WA",
                                 db="business_listing",
                                 charset="utf8mb4", port=3306, cursorclass=pymysql.cursors.DictCursor)

    # Grab current city count
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM settings WHERE name=\"bizquest_current_run\"")
        result = cursor.fetchone()
        current_state_run = int(result['value'])

    # Load state list
    state_list = json.load(open(real_path + '/state_list.json', 'rb'))
    current_state = state_list[current_state_run % len(state_list)]
    print('Loaded %s states | Current: %s' % (len(state_list), current_state))

    # Get first page, determine page count to multiprocess with
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.82 '
                      'Safari/537.36 '
    }
    results = []
    first_page_url = current_state['url'] + 'page-1/'
    print('Grabbing first page..')
    first_page_resp = requests.get(first_page_url, headers=headers).text
    print('first_page_resp', first_page_resp)
    first_page_results = get_listings_from_source(first_page_resp, current_state['state'])
    results.extend(first_page_results)

    # Find last page
    try:
        ul_str = first_page_resp.split('ul class="pagination')[1].split('</ul')[0]
        page_count = int(ul_str.split('<li')[-2].split('">')[1].split('<')[0])
    except:
        page_count = 0

    # Create combo list
    combo_list = []
    for i in range(1, page_count + 1):
        chosen_proxy = random.choice(proxy_list)
        combo_list.append({
            'state': current_state,
            'proxy': chosen_proxy,
            'page': i
        })

    # Multiprocess
    with multiprocessing.Pool(processes=thread_count) as pool:
        results = pool.map(do_work, combo_list)
    results = [item for sublist in results for item in sublist]

    # Loop through old id list and only grab new results
    old_id_list = json.load(open(real_path + '/old_id_list.json', 'rb'))
    new_result_list = []
    for result in results:
        if result['id'] not in old_id_list:
            new_result_list.append(result)
            old_id_list.append(result['id'])
    print('Found %s new results' % len(new_result_list))

    # Write new old id list
    json.dump(old_id_list, open(real_path + '/old_id_list.json', 'w'))

    # Attempt to insert into database
    print('Inserting..')
    with connection.cursor() as cursor:
        insert_sql = 'INSERT INTO business_listing (source, unique_id, title, business_type, business_url, business_image, business_address, city, state, ' \
                     'business_price, description) VALUES ("bizquest", %s, %s, "6", %s, %s, %s, %s, %s, %s, %s) ON DUPLICATE ' \
                     'KEY UPDATE id=id '

        cursor.executemany(insert_sql, [
            [x['id'], x['name'], x['url'], x['image'], x['address'], x['city'], x['state'], x['price'],
             x['description']] for x in new_result_list
        ])

        connection.commit()
        print('Done inserting!')

    # Increment current run by 1
    print('Updating current run..')
    with connection.cursor() as cursor:
        update_sql = 'UPDATE settings SET value=value+1 WHERE name="bizquest_current_run"'
        cursor.execute(update_sql)
        connection.commit()
        print('Done updating current run!')

    sleep(5)
