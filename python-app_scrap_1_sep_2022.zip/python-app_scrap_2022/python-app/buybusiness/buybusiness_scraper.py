import requests
import json
import os
import pymysql
import random
import multiprocessing
from time import sleep
import math


def get_listings_from_source(page_source, page_city, page_state):
    for listing_table_str in page_source.split('<table style="width:100%; height:92px; table-layout:fixed">')[1:]:
        pass
    return [{
        'url': x.split('href="')[1].split('"')[0],
        'address': x.split('<div class="text-darkgreen nooverflow" style="font-size:12px">')[1].split('</div')[0],
        'price': x.split('Price</td><td>')[1].split('</td')[0].replace('$', '').replace(',', ''),
        'image': x.split('<img src="')[1].split('"')[0] if 'http' in x.split('<img src="')[1].split('"')[
            0] else 'http://buybusiness.com' + x.split('<img src="')[1].split('"')[0],
        'description': x.split('_divDescription_')[1].split('">')[1].split('</div')[0],
        'id': x.split('href="')[1].split('"')[0].split('businesses/')[1].split('/')[0],
        'name': x.split('alt="')[1].split('"')[0],
        'city': page_city,
        'state': page_state
    } for x in page_source.split('<table style="width:100%; height:92px; table-layout:fixed">')[1:]]


def do_work(combo):
    c_city = combo['city']
    city_url = c_city['url']
    city_name = c_city['city']
    PROXY_RACK_DNS = "private.residential.proxyrack.net:10003"
    proxy = {"http": "http://{}:{}@{}".format('bpp', 'f4dd72-734c77-b17307-e52946-eeeccb', PROXY_RACK_DNS)}

    state = city_url.split('/us/')[1].split('/')[0].replace('-', ' ').title()
    print('Checking %s' % city_url)

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36'
    }

    results_list = []

    # Grab first page, grab results and result count to determine page count
    print('Checking page 1..')
    first_page_resp = requests.get(city_url, headers=headers, proxies=proxy).text
    try:
        result_count = first_page_resp.split('<td><b>')[1].split('</b')[0]
    except:
        return []
    if result_count == '200+':
        result_count = 200

    try:
        page_count = math.ceil(int(result_count) / 20)
    except:
        return []
    first_page_results = get_listings_from_source(first_page_resp, city_name, state)
    print('Got %s results' % len(first_page_results))
    results_list.extend(first_page_results)
    sleep(10)

    # If page_count > 1, loop through pages and grab results
    if page_count > 1:
        for page in range(2, page_count + 1):
            print('Checking page %s' % page)
            try:
                page_resp = requests.get(city_url + '?page=' + str(page), headers=headers, proxies=proxy).text
                page_results = get_listings_from_source(page_resp, city_name, state)
                print('Got %s results' % len(page_results))
                results_list.extend(page_results)
            except:
                print('Error checking page %s for city %s' % (page, city_url))
            sleep(10)
    print('Found %s total results for %s.' % (len(results_list), c_city['city']))

    return results_list


if __name__ == '__main__':
    # Header
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36'
    }

    thread_count = 25

    # Load proxy list, grab proxy for current run
    real_path = os.path.dirname(__file__)
    proxy_list = []
    with open(real_path + '/proxies.txt', 'r') as f:
        for line in f.readlines():
            if len(line.strip()) > 5:
                proxy_list.append(line.strip())

    # Create mysql connection
    connection = pymysql.connect(host="132.148.75.250", user="businesspartnership", password="Businesspartnership@123",
                                 db="bpp_staging",
                                 charset="utf8mb4", port=3306, cursorclass=pymysql.cursors.DictCursor)

    # connection = pymysql.connect(host="68.178.245.211", user="businesspartnership", password="Businesspartnership@123",
    #                              db="bpp_staging",
    #                              charset="utf8mb4", port=3306, cursorclass=pymysql.cursors.DictCursor)

    # Grab current city count
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM settings WHERE name=\"buybusiness_current_run\"")
        result = cursor.fetchone()
        current_city_run = result['value']

    # Load city list
    city_list = json.load(open(real_path + '/city_list.json', 'rb'))
    print('Loaded %s cities' % len(city_list))

    # Create combo list
    combo_list = []
    for i in range(0, thread_count):
        chosen_proxy = random.choice(proxy_list)
        proxy_list.remove(chosen_proxy)
        combo_list.append({
            'city': city_list[(int(current_city_run) + i) % len(city_list)],
            'proxy': chosen_proxy
        })

    # Multiprocess
    with multiprocessing.Pool(processes=thread_count) as pool:
        results = pool.map(do_work, combo_list)
    results = [item for sublist in results for item in sublist]

    # Loop through old id list and only grab new results
    old_id_list = json.load(open(real_path + '/old_id_list.json', 'rb'))
    new_result_list = []

    for result in results:
        if result['id'] not in old_id_list:
            new_result_list.append(result)
            old_id_list.append(result['id'])
    print('Found %s new results' % len(new_result_list))

    # Write new old id list
    json.dump(old_id_list, open(real_path + '/old_id_list.json', 'w'))

    # Attempt to insert into database
    print('Inserting..')
    try:
        with connection.cursor() as cursor:
            insert_sql = 'INSERT INTO business_listing (source, unique_id, title, business_type, business_url, business_image, business_address, city, ' \
                         'state, business_price, description) VALUES ("buybusiness", %s, %s, "6", %s, %s, %s, %s, %s, %s, ' \
                         '%s) ON DUPLICATE KEY UPDATE id=id '
            cursor.executemany(insert_sql, [
                [x['id'], x['name'], x['url'], x['image'], x['address'], x['city'], x['state'], x['price'],
                 x['description']] for x in new_result_list
            ])
            connection.commit()
            print('Done inserting!')

        # Increment current run by 1
        print('Updating current run..')
        with connection.cursor() as cursor:
            update_sql = 'UPDATE settings SET value=value+' + str(thread_count) + ' WHERE name="buybusiness_current_run"'
            cursor.execute(update_sql)
            connection.commit()
            print('Done updating current run!')
    except:
        pass
