import requests
import pymysql
import json
import math
from time import sleep
import os
import random
import multiprocessing

real_path = os.path.dirname(__file__)


def get_listings_from_source(page_source):
    try:
        json_str = '{"@context": "http://schema.org","@type": "SearchResultsPage"' + \
                   page_source.split('{"@context": "http://schema.org","@type": "SearchResultsPage"')[1].split(
                       '</script')[0].strip()
    except:
        return []
    json_obj = json.loads(json_str)
    if isinstance(json_obj['about'], list):
        return [
            {
                'name': x['item']['name'] if 'name' in x['item'] else '',
                'category': x['item']['category'] if 'category' in x['item'] else '6',
                'url': x['item']['url'],
                'description': x['item']['description'],
                'price': x['item']['price'] if 'price' in x['item'] else '',
                'image': x['item']['image'] if 'image' in x['item'] else '',
                'address': x['item']['availableAtOrFrom']['address']['streetAddress'] if 'availableAtOrFrom' in x[
                    'item'] else '',
                'city': x['item']['availableAtOrFrom']['address']['addressLocality'] if 'availableAtOrFrom' in x[
                    'item'] else '',
                'state': x['item']['availableAtOrFrom']['address']['addressRegion'] if 'availableAtOrFrom' in x[
                    'item'] else '',
                'id': x['item']['url'].split('/')[-2]
            }
            for x in json_obj['about']]
    else:
        print(json_obj['about'])
        return [
            {
                'name': json_obj['about']['name'] if 'name' in json_obj['about'] else '',
                'category': json_obj['about']['category'] if 'category' in json_obj['about'] else '6',
                'url': json_obj['about']['url'],
                'description': json_obj['about']['description'],
                'price': json_obj['about']['price'] if 'price' in json_obj['about'] else '',
                'image': json_obj['about']['image'] if 'image' in json_obj['about'] else '',
                'address': json_obj['about']['availableAtOrFrom']['address']['streetAddress'] if 'availableAtOrFrom' in
                                                                                                 json_obj[
                                                                                                     'about'] else '',
                'city': json_obj['about']['availableAtOrFrom']['address']['addressLocality'] if 'availableAtOrFrom' in
                                                                                                json_obj[
                                                                                                    'about'] else '',
                'state': json_obj['about']['availableAtOrFrom']['address']['addressRegion'] if 'availableAtOrFrom' in
                                                                                               json_obj[
                                                                                                   'about'] else '',
                'id': json_obj['about']['url'].split('/')[-2]
            }
        ]


def do_work(combo):
    c_city = combo['city']
    # c_proxy = combo['proxy']
    PROXY_RACK_DNS = "private.residential.proxyrack.net:10004"
    PROXY_RACK_DNS = "unmetered.residential.proxyrack.net:10001"
    proxy = '38.84.70.106'
    username = 'BPP'
    password = 'strawberry22'
    c_proxy_var = {
        "http": "http://{}:{}@{}".format('bpp', 'f4dd72-734c77-b17307-e52946-eeeccb', PROXY_RACK_DNS)
    }
    proxy_var = {"http": "http://{}:{}@{}".format(username, password, PROXY_RACK_DNS)
    }
    city_url = 'http://webcache.googleusercontent.com/search?q=cache:https://www.loopnet.com/search/commercial-real-estate/' + c_city['city_url']
    print('Checking %s' % city_url)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36'
    }
    results_list = []

    # Grab first page, grab results and result count to determine page count
    print('Checking page 1..')
    # import pdb
    # pdb.set_trace()
    # proxy = {"http": "http://{}:{}@{}".format('bpp', 'f4dd72-734c77-b17307-e52946-eeeccb', PROXY_RACK_DNS)}
    first_page_resp = requests.get(city_url, headers=headers, proxies=c_proxy_var).text
    print('CITY_URLLLLLL', city_url)
    print('FIRST_PAGE_RESPONCE', first_page_resp)
    print('checkin page count...')
    try:
        result_count = first_page_resp.split('class="total-results-paging-digits">')[1].split("</span>")[0].split(" ")[
            -1]
        page_count = math.ceil(int(result_count))
        print("total %s pages" % page_count)

        # If page_count > 1, loop through pages and grab results
        if page_count > 1:
            for page in range(2, page_count + 1):
                print('Checking page %s' % page)
                try:
                    page_resp = requests.get(city_url + str(page), headers=headers, proxies=c_proxy_var).text
                    page_results = get_listings_from_source(page_resp)
                    print('Got %s results' % len(page_results))
                    results_list.extend(page_results)
                except:
                    print('Error checking page %s for city %s' % (page, city_url))
                sleep(10)
    except:
        first_page_results = get_listings_from_source(first_page_resp)
        print('Got %s results for first page' % len(first_page_results))
        results_list.extend(first_page_results)
        sleep(10)
    print('Found %s total results for %s.' % (len(results_list), c_city['city_url']))

    return results_list


if __name__ == '__main__':
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36'
    }

    thread_count = 10

    # Load proxy list, grab proxy for current run
    real_path = os.path.dirname(__file__)
    proxy_list = []
    with open(real_path + '/proxies.txt', 'r') as f:
        for line in f.readlines():
            if len(line.strip()) > 5:
                proxy_list.append(line.strip())

    # Create mysql connection
    # connection = pymysql.connect(host="localhost", user="businesspartnership", password="Businesspartnership@123", db="bpp_staging",
    #                              charset="utf8mb4", port=3306, cursorclass=pymysql.cursors.DictCursor)
    # #connection = pymysql.connect(host="BusinessPartnershipPortal.chetu.com", user="businesspartnership", password="Businesspartnership@123", db="BusinessPartnershipPortal",charset="utf8mb4", port=2246)
    connection = pymysql.connect(host="132.148.75.250", user="businesspartnership", password="Businesspartnership@123",
                                 db="bpp_staging",
                                 charset="utf8mb4", port=3306, cursorclass=pymysql.cursors.DictCursor)
    # Grab current city count
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM settings WHERE name=\"current_city_run\"")
        result = cursor.fetchone()
        current_city_run = result['value']

    # Load city list
    #city_list = json.load(open('/city_list.json', 'rb'))
    city_list = json.load(open(real_path + '/city_list.json', 'rb'))
    print('Loaded %s cities' % len(city_list))

    # Create combo list
    combo_list = []
    for i in range(0, thread_count):
        chosen_proxy = random.choice(proxy_list)
        proxy_list.remove(chosen_proxy)
        combo_list.append({
            'city': city_list[(int(current_city_run) + i) % len(city_list)],
            'proxy': chosen_proxy
        })

    # Multiprocess
    with multiprocessing.Pool(processes=thread_count) as pool:
        results = pool.map(do_work, combo_list)
    results = [item for sublist in results for item in sublist]

    # Attempt to insert into database
    print('Inserting..')
    print(results)
    # print([x['id'] for x in results])
    with connection.cursor() as cursor:
        xd=1000
        list_of_lists = [results[i:i + xd] for i in range(0, len(results), xd)]
        print(list_of_lists)
        insert_sql = 'INSERT INTO business_listing (source, unique_id, title, business_type, business_url, business_image, business_address, city, state, '\
                     'business_price, description) VALUES ("loopnet", %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) ON DUPLICATE KEY '\
                     'UPDATE id=id '


        cursor.executemany(insert_sql, [
            [x['id'], x['name'], x['category'], x['url'], x['image'], x['address'], x['city'], x['state'],
             x['price'],
             x['description']] for x in results
        ])
        connection.commit()

        print('Done inserting!')

    # Increment current run by 1
    print('Updating current run..')
    with connection.cursor() as cursor:
        update_sql = 'UPDATE settings SET value=value+' + str(thread_count) + ' WHERE name="current_city_run"'
        cursor.execute(update_sql)
        connection.commit()
        print('Done updating current run!')
