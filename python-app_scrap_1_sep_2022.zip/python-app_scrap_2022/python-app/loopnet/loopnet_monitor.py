from subprocess import Popen
import os
from time import sleep

real_path = os.path.dirname(__file__)
print("\nStarting listing scraper..")
p = Popen("python3 \"%s/loopnet_scraper.py\"" % real_path, shell=True)
while True:
    if p.poll() is not None:
        break

