import pymysql

connection = pymysql.connect(host="BusinessPartnershipPortal.chetu.com", user="businesspartnership", password="Businesspartnership@123", db="BusinessPartnershipPortal",
                                 charset="utf8mb4", port=2246)
print("connection succesful",connection)

with connection.cursor() as cursor:
    cursor.execute("Show tables;")
    myresult = cursor.fetchall()

print([i for i in myresult])