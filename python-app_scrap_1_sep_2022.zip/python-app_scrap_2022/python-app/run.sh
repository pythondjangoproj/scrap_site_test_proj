#!/bin/bash

#source /var/www/new_env/bin/activate
cd /var/www/python-app/ 
#python multiproc.py 

#/var/www/new_env/bin/python /var/www/python-app/buybusiness/buybusiness_monitor.py 
/var/www/new_env/bin/python /var/www/python-app/businessesforsale/businessesforsale_monitor.py 
/var/www/new_env/bin/python /var/www/python-app/loopnet/loopnet_monitor.py 
