import subprocess

#bizquest_process = subprocess.Popen(["/var/www/new_env/bin/python", "/var/www/python-app/bizquest/bizquest_monitor.py"])
businessesforsale_process = subprocess.Popen(["/var/www/new_env/bin/python", "/var/www/python-app/businessesforsale/businessesforsale_monitor.py"])
#buybusiness_process = subprocess.Popen(["/var/www/new_env/bin/python", "/var/www/python-app/buybusiness/buybusiness_monitor.py"])
#loopnet_process = subprocess.Popen(["/var/www/new_env/bin/python", "/var/www/python-app/loopnet/loopnet_monitor.py"])


#bizquest_process.wait()
