import os, sys
my_dir = os.path.dirname(sys.argv[0])

os.system('%s %s' % (sys.executable, os.path.join(my_dir, 'bizquest/bizquest_monitor.py 1')))
os.system('%s %s' % (sys.executable, os.path.join(my_dir, 'businessesforsale/businessesforsale_monitor.py 1')))
os.system('%s %s' % (sys.executable, os.path.join(my_dir, 'buybusiness/buybusiness_monitor.py 1')))
#os.system('%s %s' % (sys.executable, os.path.join(my_dir, 'loopnet/loopnet_monitor.py 1')))
